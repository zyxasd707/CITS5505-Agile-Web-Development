/* ============================================================
   script.js — AgileWebDev2026 Tutorial Week 4
   外部 JavaScript 文件 External JavaScript File
   对应讲座 Page 5–18 的完整代码
   ============================================================ */

/* ===========================================================
   SECTION 1: 基础 alert 函数
   Page 8 — 将 alert 封装成可复用函数
   =========================================================== */

/**
 * showAlert(msg)
 * 接收一个消息参数并弹出对话框
 * Receives a message parameter and shows an alert dialog
 * @param {string} msg - 要显示的消息 The message to display
 */
function showAlert(msg) {
    alert(msg);                      // 弹出提示框 Show alert dialog
}


/* ===========================================================
   SECTION 2: myFunction — 获取用户输入并弹出
   Page 11 — prompt 获取输入，传给 showAlert
   =========================================================== */

/**
 * myFunction()
 * 弹出输入框，读取用户输入，再用 showAlert 显示
 * Shows a prompt, reads user input, then calls showAlert
 */
function myFunction() {
    let message = prompt("Enter your message:"); // 弹出输入框 Show input dialog
    showAlert(message);                          // 调用上面的函数 Call showAlert
}


/* ===========================================================
   SECTION 3: sum() — 数字相加（含 Bug 演示 + 修复）
   Page 12–13 — prompt 返回 string，需要 parseInt 转换
   =========================================================== */

/**
 * sum()
 * 从用户获取两个数字并相加
 * Gets two numbers from user and adds them
 *
 * ⚠️ 重要：prompt() 返回的永远是 string 类型！
 * ⚠️ Important: prompt() ALWAYS returns a string type!
 * 直接相加会变成字符串拼接："2"+"3"="23" 而非 5
 * Direct + will concatenate strings: "2"+"3"="23" not 5
 * 解决方案：用 parseInt() 强制转换为整数
 * Solution: Use parseInt() to convert to integer
 */
function sum() {
    // parseInt() 将 prompt 返回的字符串转换为整数
    // parseInt() converts the string from prompt to an integer
    let num1 = parseInt(prompt("Enter the first number:"));
    let num2 = parseInt(prompt("Enter the second number:"));

    let result = num1 + num2;        // 现在是数字加法 Now it's numeric addition

    // console.log 是调试的最佳工具，不会阻塞页面
    // console.log is the best debugging tool, does NOT block the page
    console.log("The sum is: " + result); // 在控制台查看结果 See result in console

    // typeof 可以检查变量的数据类型
    // typeof checks the data type of a variable
    console.log("Type of num1:", typeof num1); // 修复后应显示 "number" Should show "number"
    console.log("Type of num2:", typeof num2); // 修复后应显示 "number" Should show "number"
}


/* ===========================================================
   SECTION 4: changeColor() — 通过 ID 修改单个元素
   Page 9 — getElementById 获取元素，修改其颜色
   =========================================================== */

/**
 * changeColor()
 * 点击按钮后，将 id="heding1" 的 h1 颜色改为红色
 * On button click, changes color of h1 with id="heding1" to red
 */
function changeColor() {
    // document.getElementById("id名") 通过 ID 获取唯一元素
    // document.getElementById("idName") gets the unique element by its ID
    document.getElementById("heding1").style.color = "red";
    //                          ↑               ↑         ↑
    //                       元素ID         CSS属性    新颜色值
    //                       Element ID   CSS property  New value
}


/* ===========================================================
   SECTION 5: changeHeading() — 通过 TagName 修改所有同类元素
   Page 9–11 — getElementsByTagName 返回集合，需要循环遍历
   =========================================================== */

/**
 * changeHeading()
 * 将页面上所有 h1 元素的文字内容改为用户输入的文字
 * Changes text content of ALL h1 elements to user's input
 *
 * 类比 Analogy：
 * getElementsByTagName 就像"找出班上所有穿红色衣服的学生"
 * getElementsByTagName is like "find all students wearing red"
 * 然后你需要逐个处理（循环）
 * Then you need to handle each one (loop)
 */
function changeHeading() {
    // getElementsByTagName 返回所有匹配标签的"类数组"集合
    // Returns an array-like collection of all matching elements
    let headings = document.getElementsByTagName("h1");

    // 用 for 循环遍历每个 h1 元素
    // Use for loop to iterate through each h1 element
    for (let i = 0; i < headings.length; i++) {
        // 每次循环弹出输入框，让用户为每个标题输入不同的文字
        // Each iteration prompts for a different text per heading
        let message = prompt("Enter the new heading text for heading " + (i + 1) + ":");

        // innerText 修改元素的纯文本内容（不解析 HTML 标签）
        // innerText changes the plain text content (does NOT parse HTML tags)
        headings[i].innerText = message;
        //        ↑
        //   通过下标访问集合中的第 i 个元素
        //   Access the i-th element in the collection by index
    }
}


/* ===========================================================
   SECTION 6: factorial(n) — 递归函数（含无限递归演示）
   Page 14–17
   =========================================================== */

/**
 * ❌ 错误版本（用于理解 Stack Overflow）
 * Wrong version (to understand Stack Overflow)
 * 没有 base case → 无限递归 → 栈溢出
 * No base case → infinite recursion → stack overflow
 *
 * function factorialBroken(n) {
 *     return n * factorialBroken(n - 1);  // 永无止境 Never ends
 * }
 * 结果 Result: Uncaught RangeError: Maximum call stack size exceeded
 * 注意：页面仍会加载！浏览器会自动忽略错误并继续渲染。
 * Note: Page still loads! Browser ignores the error and renders.
 */

/**
 * ✅ 正确版本（有 base case）
 * Correct version with base case
 *
 * factorial(5) 的计算过程：
 * factorial(5) = 5 × factorial(4)
 *                    = 4 × factorial(3)
 *                         = 3 × factorial(2)
 *                              = 2 × factorial(1)
 *                                   = 1  ← base case！
 * 结果 Result: 5×4×3×2×1 = 120
 *
 * @param {number} n - 要计算阶乘的数 The number to compute factorial of
 * @returns {number} n 的阶乘 n factorial
 */
function factorial(n) {
    // base case: 0! = 1, 1! = 1
    // 没有这个，函数会无限调用自身！
    // Without this, function calls itself forever!
    if (n === 0 || n === 1) {
        return 1;                    // 返回1，停止递归 Return 1, stop recursion
    }

    // 递归调用：n × (n-1)!
    // Recursive call: n × (n-1)!
    return n * factorial(n - 1);
}

// 在控制台输出 factorial(5) 的结果
// Output factorial(5) result to console
console.log(factorial(5));           // 输出 120 Outputs 120


/* ===========================================================
   SECTION 7: buttonClicked() — 全局变量计数器
   Page 17–18 — 全局变量在函数调用之间保留值
   =========================================================== */

/**
 * 全局变量：在任何函数外部声明
 * Global variable: declared outside any function
 *
 * 关键区别 Key difference:
 * - 全局变量 Global: 整个程序共享，函数调用间值保留
 *                    Shared across whole program, value persists between calls
 * - 局部变量 Local:  只在函数内存在，每次调用重新初始化
 *                    Only exists inside function, re-initialized each call
 */
let buttonPresses = 0;               // 从0开始计数 Start counting from 0

/**
 * buttonClicked()
 * 每次按钮被点击，计数器加1并在控制台输出
 * Each time button is clicked, increment counter and log to console
 */
function buttonClicked() {
    buttonPresses++;                 // 等同于 buttonPresses = buttonPresses + 1
    console.log("The button has been pressed " + buttonPresses + " times.");
    // 控制台显示：The button has been pressed 1 times.
    // 再按一次：  The button has been pressed 2 times.
    // 以此类推   And so on...
}
